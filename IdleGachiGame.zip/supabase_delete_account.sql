-- IdleGachi: let a signed-in player delete their own account.
-- Run this once in the Supabase dashboard: SQL Editor > New query > paste > Run.
-- After it runs, the "Delete my account" button in the game's Account window works,
-- and the same email can sign up again right away.

create or replace function public.delete_my_account()
returns void
language plpgsql
security definer
set search_path = public, auth
as $$
declare
  uid uuid := auth.uid();
  r record;
begin
  if uid is null then
    raise exception 'not signed in';
  end if;

  -- Remove this player's rows from every public table that points at auth.users
  -- (saves, profiles, chat, chat prefs, reports, leaderboard scores, and so on),
  -- whatever the column is called.
  for r in
    select n.nspname as sch, c.relname as tbl, a.attname as col
    from pg_constraint k
    join pg_class c on c.oid = k.conrelid
    join pg_namespace n on n.oid = c.relnamespace
    join pg_attribute a on a.attrelid = c.oid and a.attnum = k.conkey[1]
    where k.contype = 'f'
      and k.confrelid = 'auth.users'::regclass
      and n.nspname = 'public'
      and array_length(k.conkey, 1) = 1
  loop
    execute format('delete from %I.%I where %I = $1', r.sch, r.tbl, r.col) using uid;
  end loop;

  -- Finally remove the login itself. This frees the email for a new sign up.
  delete from auth.users where id = uid;
end;
$$;

revoke all on function public.delete_my_account() from public, anon;
grant execute on function public.delete_my_account() to authenticated;
