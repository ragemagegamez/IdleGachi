#!/usr/bin/env python3
"""Replace a Gachimon's art in index.html with your own GIF.

Usage:  python3 tools/replace_sprite.py index.html i1 my_embyte.gif

  i1 = the Gachimon id (see names.csv in gachimon_pixel_art.zip, e.g. i1 = Embyte, c1 = Cinderpup)
  GIF frame 1 = idle pose. GIF frame 2 (optional) = action pose, shown while it works, fights or swings.
  A one-frame GIF or PNG works too: it just stays the same pose.
Needs Pillow:  pip install pillow
"""
import sys, json, re
from PIL import Image

html, sid, path = sys.argv[1:4]
im = Image.open(path)
frames = []
for i in range(getattr(im, 'n_frames', 1)):
    im.seek(i)
    frames.append(im.convert('RGBA').copy())
frames = frames[:2]
if len(frames) == 1:
    frames.append(frames[0])

def bbox(f):
    pts = [(x, y) for y in range(f.height) for x in range(f.width) if f.getpixel((x, y))[3] >= 128]
    return min(p[0] for p in pts), min(p[1] for p in pts), max(p[0] for p in pts), max(p[1] for p in pts)

bs = [bbox(f) for f in frames]
x0 = min(b[0] for b in bs); y0 = min(b[1] for b in bs)
x1 = max(b[2] for b in bs); y1 = max(b[3] for b in bs)
w, h = x1 - x0 + 1, y1 - y0 + 1
N = max(w, h)
mx = (N - w) // 2
pal, rows = [], []
for f in frames:
    g = [[0] * N for _ in range(N)]
    for y in range(h):
        for x in range(w):
            r, gg, b, a = f.getpixel((x0 + x, y0 + y))
            if a >= 128:
                c = '#%02x%02x%02x' % (r, gg, b)
                if c not in pal:
                    pal.append(c)
                g[N - h + y][mx + x] = pal.index(c) + 1
    rows.append(''.join(format(v, 'x') for r in g for v in r))
if len(pal) > 15:
    sys.exit('Too many colors (%d). The limit is 15 per Gachimon.' % len(pal))

s = open(html, encoding='utf-8').read()
m = re.search(r'const CSPR=(\{.*?\}),CGR=\{\};', s)
if not m:
    sys.exit('Could not find the sprite table in ' + html)
tbl = json.loads(m.group(1))
tbl[sid] = {'c': pal, 'n': N, 'f': rows}
s = s[:m.start(1)] + json.dumps(tbl, separators=(',', ':')) + s[m.end(1):]
open(html, 'w', encoding='utf-8').write(s)
print('Done: %s is now %dx%d with %d colors. Custom sprites in the game: %s' % (sid, N, N, len(pal), ', '.join(sorted(tbl))))
